import logging

from odoo import SUPERUSER_ID, api

_logger = logging.getLogger(__name__)

try:
    from odoo.addons.base_multi_company import hooks
except ImportError:
    _logger.info("Cannot find `base_multi_company` module in addons path.")


def post_init_hook(cr, registry):
    with api.Environment.manage():
        env = api.Environment(cr, SUPERUSER_ID, {})
        hooks.set_security_rule(env, "base.res_partner_rule")
        partner_obj = env["res.partner"]
        table_name = partner_obj._fields["company_ids"].relation
        column1 = partner_obj._fields["company_ids"].column1
        column2 = partner_obj._fields["company_ids"].column2
        sql = """
            WITH user_companies AS (
            SELECT partner_id AS partner, cid AS company FROM res_users INNER JOIN res_company_users_rel ON id = user_id 
            WHERE partner_id IS NOT NULL
            )
            INSERT INTO {}
            ({}, {})
            SELECT id, 
            CASE 
                WHEN company IS NULL 
                THEN company_id 
                ELSE company 
            END 
            FROM res_partner 
            LEFT JOIN 
            user_companies 
            on id = partner WHERE company_id IS NOT NULL 
            ORDER BY id;
        """.format(table_name, column1, column2)
        env.cr.execute(sql)


def uninstall_hook(cr, registry):
    """ Restore product rule to base value.

    Args:
        cr (Cursor): Database cursor to use for operation.
        rule_ref (string): XML ID of security rule to remove the
            `domain_force` from.
    """
    with api.Environment.manage():
        env = api.Environment(cr, SUPERUSER_ID, {})
        # Change access rule
        rule = env.ref("base.res_partner_rule")
        rule.write(
            {
                "active": False,
                "domain_force": (
                    "['|','|',('company_id.child_ids','child_of',"
                    "[user.company_id.id]),('company_id','child_of',"
                    "[user.company_id.id]),('company_id','=',False)]"
                ),
            }
        )
