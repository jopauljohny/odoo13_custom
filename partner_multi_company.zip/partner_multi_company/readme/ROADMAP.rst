* Allow to select different companies from the parent in contacts.
