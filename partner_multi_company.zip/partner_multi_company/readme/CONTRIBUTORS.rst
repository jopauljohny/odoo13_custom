* Oihane Crucelaegui <oihanecruce@gmail.com>
* Dave Lasley <dave@laslabs.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza <pedro.baeza@tecnativa.com>
  * Vicent Cubells <vicent.cubells@tecnativa.com>

* Kitti Upariphutthiphong <kittiu@ecosoft.co.th>
